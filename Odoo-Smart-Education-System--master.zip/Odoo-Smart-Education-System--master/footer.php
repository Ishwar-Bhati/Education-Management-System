<center>
		<footer>
		
		<p>Copyright &copy; Smart Education System</p>
		</footer>
</center>

