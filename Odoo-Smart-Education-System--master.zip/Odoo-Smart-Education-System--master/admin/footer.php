<div class="pull-right">
		<footer>
           <p>Programmed by: Ketul Makwana & Happy Mistry</p>
        <footer>
</div>