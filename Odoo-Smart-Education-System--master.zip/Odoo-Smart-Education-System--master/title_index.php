<div style="height:30px">
 
</div>
<div class="row-fluid">
	<div class="span4">
		<img class="index_logo" src="./admin/images/clg.png">
	</div>	
	<div class="span8">
		<div class="title">
			<h3>
				<p>Smart Education System</p>
			</h3>		
		</div>
	</div>							
</div>
				